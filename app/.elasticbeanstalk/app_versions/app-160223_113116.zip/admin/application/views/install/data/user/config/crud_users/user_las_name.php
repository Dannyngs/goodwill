<?php exit; ?>
{"field":"user_las_name","label":"Last name","type":"text","type_options":{"size":"390","width":"300","height":"100","thumbnail":"mini"},"validation":"notEmpty"}