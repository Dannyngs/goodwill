<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-04 17:09:25 --> Severity: Notice  --> Undefined index: sort /home/cm/newcmweb.hk/themes/npclimited/admin/application/third_party/scrud/libraries/crud.php 1228
