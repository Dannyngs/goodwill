<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-16 05:39:11 --> Severity: Notice  --> Only variable references should be returned by reference E:\goodwill\app\admin\system\core\Common.php 257
ERROR - 2016-02-16 05:39:11 --> Severity: Notice  --> Only variable references should be returned by reference E:\goodwill\app\admin\system\core\Common.php 257
