<?php exit; ?>
{"field":"date","label":"date","type":"date","type_options":{"size":"210","width":"300","height":"100","thumbnail":"mini"},"validation":""}