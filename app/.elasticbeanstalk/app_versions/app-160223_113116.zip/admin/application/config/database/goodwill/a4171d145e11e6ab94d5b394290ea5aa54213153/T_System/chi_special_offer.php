<?php exit; ?>
{"field":"chi_special_offer","label":"chi_special","type":"editor","type_options":{"size":"210","width":"300","height":"100","thumbnail":"mini"},"validation":""}