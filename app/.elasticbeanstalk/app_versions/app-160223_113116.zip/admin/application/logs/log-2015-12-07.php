<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-07 18:39:39 --> Severity: Notice  --> Undefined index: key /home/cm/newcmweb.hk/themes/npclimited/admin/application/third_party/scrud/libraries/crud.php 1123
ERROR - 2015-12-07 18:58:19 --> Severity: Notice  --> Undefined index: sort /home/cm/newcmweb.hk/themes/npclimited/admin/application/third_party/scrud/libraries/crud.php 1228
