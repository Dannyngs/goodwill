<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-30 00:21:13 --> Severity: Warning  --> mkdir(): File exists /home/cm/newcmweb.hk/themes/npclimited/admin/application/third_party/scrud/class/functions.php 23
ERROR - 2015-11-30 00:21:13 --> Severity: Warning  --> mkdir(): File exists /home/cm/newcmweb.hk/themes/npclimited/admin/application/third_party/scrud/class/functions.php 23
