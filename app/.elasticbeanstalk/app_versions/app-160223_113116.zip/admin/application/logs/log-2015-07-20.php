<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-20 15:37:36 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`tipster/record`, CONSTRAINT `record_ibfk_1` FOREIGN KEY (`tipster_id`) REFERENCES `tipster` (`id`))
