<div style="padding:2px 8px 7px 8px; 
     margin-bottom:20px; 
     background: #FFFFFF;
     box-shadow: 0 2px 6px rgba(0, 0, 0, 0.25); 
     border: 1px solid #e8e8e8; 
     -moz-border-radius: 7px; 
     -khtml-border-radius: 7px; 
     -webkit-border-radius: 7px; 
     border-radius: 7px;">
    <center><h3>CodeIgniter Admin Pro INSTALLATION</h3></center>
    <p><b>Congratulations</b>, you have successfully installed the CodeIgniter Admin Pro. <a href="<?php echo base_url(); ?>index.php/admin/login">Click here</a>  to login with users below.</p>
    <br />
    Administrator (full right) :<br /> account: <b>admin</b>  password: <b>123456</b><br/><br/>
    manager (read,edit,delete):<br /> account: <b>manager</b> password: <b>123456</b><br/><br/>
    User (read only):<br /> account: <b>user</b> password: <b>123456</b><br/><br/>
    User (only access  their own records):<br /> account: <b>user2</b> password: <b>123456</b>
    <hr />
    <footer>
        <p><?php echo $this->lang->line('copyright_company'); ?></p>
    </footer>
</div>