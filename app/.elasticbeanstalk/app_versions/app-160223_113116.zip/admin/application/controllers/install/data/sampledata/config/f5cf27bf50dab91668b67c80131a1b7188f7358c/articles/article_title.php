<?php exit; ?>
{"field":"article_title","label":"Title","type":"text","type_options":{"size":"210","width":"300","height":"100","thumbnail":"mini"},"validation":"notEmpty"}