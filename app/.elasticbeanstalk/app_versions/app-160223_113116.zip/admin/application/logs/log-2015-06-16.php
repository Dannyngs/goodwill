<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-16 11:04:34 --> Severity: Warning  --> mkdir(): File exists /Users/cm/site/cr/application/third_party/scrud/class/functions.php 23
ERROR - 2015-06-16 11:04:34 --> Severity: Warning  --> mkdir(): File exists /Users/cm/site/cr/application/third_party/scrud/class/functions.php 23
ERROR - 2015-06-16 11:21:29 --> Query error: Field 'result' doesn't have a default value
ERROR - 2015-06-16 11:21:49 --> Query error: Field 'result' doesn't have a default value
ERROR - 2015-06-16 11:25:10 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tipster`.`record`, CONSTRAINT `record_ibfk_2` FOREIGN KEY (`result`) REFERENCES `result` (`id`))
ERROR - 2015-06-16 11:31:23 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tipster`.`record`, CONSTRAINT `record_ibfk_2` FOREIGN KEY (`result`) REFERENCES `result` (`id`))
ERROR - 2015-06-16 12:00:28 --> Query error: Field 'id' doesn't have a default value
ERROR - 2015-06-16 12:24:04 --> Query error: Data too long for column 'mypick' at row 1
