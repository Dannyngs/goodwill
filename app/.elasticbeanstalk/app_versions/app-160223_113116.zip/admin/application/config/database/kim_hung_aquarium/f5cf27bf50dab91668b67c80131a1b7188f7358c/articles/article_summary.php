<?php exit; ?>
{"field":"article_summary","label":"Summary","type":"editor","type_options":{"size":"210","width":"300","height":"100","thumbnail":"mini"},"validation":""}