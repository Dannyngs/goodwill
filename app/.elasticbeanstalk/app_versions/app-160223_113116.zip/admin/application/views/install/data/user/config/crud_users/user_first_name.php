<?php exit; ?>
{"field":"user_first_name","label":"First name","type":"text","type_options":{"size":"390","width":"300","height":"100","thumbnail":"mini"},"validation":"notEmpty"}