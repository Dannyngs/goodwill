<?php exit; ?>
{"field":"tel1","label":"tel1","type":"text","type_options":{"size":"210","width":"300","height":"100","thumbnail":"mini"},"validation":""}