<?php exit; ?>
{"field":"category_description","label":"Description","type":"editor","type_options":{"size":"210","width":"300","height":"100","thumbnail":"mini"},"validation":""}