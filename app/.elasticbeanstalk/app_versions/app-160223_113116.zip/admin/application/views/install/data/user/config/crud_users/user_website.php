<?php exit; ?>
{"field":"user_website","label":"Website","type":"text","type_options":{"size":"527","width":"300","height":"100","thumbnail":"mini"},"validation":""}