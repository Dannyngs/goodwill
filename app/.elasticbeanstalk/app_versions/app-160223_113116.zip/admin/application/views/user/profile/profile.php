<div class="container">
         <?php echo $user_menu; ?>
        <?php echo $content; ?>
    </div>
</div>