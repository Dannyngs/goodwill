<?php exit; ?>
{"field":"countryCode","label":"Code","type":"text","type_options":{"size":"50","width":"300","height":"100","thumbnail":"mini"},"validation":"notEmpty"}