<div class="container">
	<div class="row">
		<div class="span4 offset4 well">
			 <?php echo sprintf($this->lang->line('your_account_is_activated'),  base_url().'index.php/admin/login');?>
		</div>
	</div>
</div>