<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-21 17:35:48 --> Severity: Warning  --> mysqli_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\wamp\www\admin\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2015-11-21 17:35:48 --> Unable to connect to the database
ERROR - 2015-11-21 17:36:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\admin\application\controllers\install\index.php 52
ERROR - 2015-11-21 17:36:36 --> Severity: Warning  --> mkdir(): File exists D:\wamp\www\admin\application\third_party\scrud\class\functions.php 23
ERROR - 2015-11-21 17:44:16 --> Severity: Warning  --> imagecreatefrompng(): 'D:\wamp\www\admin\media/images/1448124256-._Teddy_CN-02.png' is not a valid PNG file D:\wamp\www\admin\application\third_party\scrud\class\Image.php 134
ERROR - 2015-11-21 17:44:16 --> Severity: Warning  --> imagecopyresampled() expects parameter 2 to be resource, boolean given D:\wamp\www\admin\application\third_party\scrud\class\Image.php 142
ERROR - 2015-11-21 17:44:16 --> Severity: Warning  --> imagedestroy() expects parameter 1 to be resource, boolean given D:\wamp\www\admin\application\third_party\scrud\class\Image.php 154
