<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-10 18:51:57 --> Severity: Notice  --> Undefined index: img_data /home/cm/newcmweb.hk/themes/npclimited/admin/application/third_party/scrud/libraries/crud.php 718
ERROR - 2015-12-10 18:51:57 --> Severity: Notice  --> Undefined index: img_data /home/cm/newcmweb.hk/themes/npclimited/admin/application/third_party/scrud/libraries/crud.php 719
ERROR - 2015-12-10 18:51:57 --> Severity: Notice  --> Undefined index: img_data /home/cm/newcmweb.hk/themes/npclimited/admin/application/third_party/scrud/libraries/crud.php 721
ERROR - 2015-12-10 18:51:57 --> Severity: Notice  --> Undefined index: img_data /home/cm/newcmweb.hk/themes/npclimited/admin/application/third_party/scrud/libraries/crud.php 723
ERROR - 2015-12-10 18:51:57 --> Severity: Notice  --> Undefined index:  /home/cm/newcmweb.hk/themes/npclimited/admin/application/third_party/scrud/class/FileUpload.php 143
ERROR - 2015-12-10 19:10:13 --> Severity: Notice  --> Undefined index: img_data /home/cm/newcmweb.hk/themes/npclimited/admin/application/third_party/scrud/libraries/crud.php 718
ERROR - 2015-12-10 19:10:13 --> Severity: Notice  --> Undefined index: img_data /home/cm/newcmweb.hk/themes/npclimited/admin/application/third_party/scrud/libraries/crud.php 719
ERROR - 2015-12-10 19:10:13 --> Severity: Notice  --> Undefined index: img_data /home/cm/newcmweb.hk/themes/npclimited/admin/application/third_party/scrud/libraries/crud.php 721
ERROR - 2015-12-10 19:10:13 --> Severity: Notice  --> Undefined index: img_data /home/cm/newcmweb.hk/themes/npclimited/admin/application/third_party/scrud/libraries/crud.php 723
ERROR - 2015-12-10 19:10:13 --> Severity: Notice  --> Undefined index:  /home/cm/newcmweb.hk/themes/npclimited/admin/application/third_party/scrud/class/FileUpload.php 143
ERROR - 2015-12-10 20:16:57 --> Query error: Unknown column 'product.id' in 'order clause'
ERROR - 2015-12-10 20:17:13 --> Query error: Unknown column 'product.id' in 'order clause'
ERROR - 2015-12-10 21:08:20 --> Query error: Unknown column 'product.id' in 'order clause'
ERROR - 2015-12-10 21:13:18 --> Query error: Unknown column 'category.id' in 'order clause'
ERROR - 2015-12-10 21:16:15 --> Query error: Unknown column 'category.id' in 'order clause'
ERROR - 2015-12-10 21:16:19 --> Query error: Unknown column 'category.id' in 'order clause'
ERROR - 2015-12-10 21:16:21 --> Query error: Unknown column 'category.id' in 'order clause'
