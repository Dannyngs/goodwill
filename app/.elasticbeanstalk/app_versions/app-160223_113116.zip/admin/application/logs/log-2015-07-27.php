<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-27 20:54:29 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tipster/record`, CONSTRAINT `record_ibfk_1` FOREIGN KEY (`tipster_id`) REFERENCES `tipster` (`id`))
ERROR - 2015-07-27 20:54:34 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tipster/record`, CONSTRAINT `record_ibfk_1` FOREIGN KEY (`tipster_id`) REFERENCES `tipster` (`id`))
