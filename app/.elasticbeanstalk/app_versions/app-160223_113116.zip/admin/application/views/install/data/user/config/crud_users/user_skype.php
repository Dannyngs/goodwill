<?php exit; ?>
{"field":"user_skype","label":"Skype","type":"text","type_options":{"size":"210","width":"300","height":"100","thumbnail":"mini"},"validation":""}