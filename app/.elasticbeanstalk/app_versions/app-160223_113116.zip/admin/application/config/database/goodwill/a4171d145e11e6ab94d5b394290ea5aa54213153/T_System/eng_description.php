<?php exit; ?>
{"field":"eng_description","label":"eng_description","type":"editor","type_options":{"size":"210","width":"300","height":"100","thumbnail":"mini"},"validation":""}