<?php exit; ?>
{"field":"countryName","label":"Country Name","type":"text","type_options":{"size":"254","width":"300","height":"100","thumbnail":"mini"},"validation":"notEmpty"}