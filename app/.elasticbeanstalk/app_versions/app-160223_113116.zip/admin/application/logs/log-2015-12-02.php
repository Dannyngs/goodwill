<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-02 10:56:06 --> Severity: Warning  --> imagecreatefrompng(): '/home/cm/newcmweb.hk/themes/npclimited/admin/media/images/1449024966-._Teddy_CN-02.png' is not a valid PNG file /home/cm/newcmweb.hk/themes/npclimited/admin/application/third_party/scrud/class/Image.php 134
ERROR - 2015-12-02 10:56:06 --> Severity: Warning  --> imagecopyresampled() expects parameter 2 to be resource, boolean given /home/cm/newcmweb.hk/themes/npclimited/admin/application/third_party/scrud/class/Image.php 142
ERROR - 2015-12-02 10:56:06 --> Severity: Warning  --> imagedestroy() expects parameter 1 to be resource, boolean given /home/cm/newcmweb.hk/themes/npclimited/admin/application/third_party/scrud/class/Image.php 154
