<div class="container">
	<div class="row">
		<div class="span4 offset4 well">
			<?php echo sprintf($this->lang->line('you_have_been_registered'), base_url().'index.php/admin/login');?>
		</div>
	</div>
</div>