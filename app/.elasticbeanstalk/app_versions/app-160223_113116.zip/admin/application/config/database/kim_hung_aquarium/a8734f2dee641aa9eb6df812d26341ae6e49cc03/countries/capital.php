<?php exit; ?>
{"field":"capital","label":"Capital","type":"text","type_options":{"size":"254","width":"300","height":"100","thumbnail":"mini"},"validation":"notEmpty"}