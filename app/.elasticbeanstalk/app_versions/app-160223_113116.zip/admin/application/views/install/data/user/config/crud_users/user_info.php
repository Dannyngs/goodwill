<?php exit; ?>
{"field":"user_info","label":"User information","type":"editor","type_options":{"size":"210","width":"300","height":"100","thumbnail":"mini"},"validation":""}